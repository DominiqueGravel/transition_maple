# Take previous evaluation of maximum likelihood estimates
par = read.table("../v2/scripts/second_order/par.txt")

# Compute the initial step
par_initStep =lapply(par, function(x){x+0.01})# Lower bounds
par_lo = list()
par_lo$ac0 = -10
par_lo$act1 = -20
par_lo$act2 = -10
par_lo$acp1 = -10
par_lo$acp2 = -10 

par_lo$ad0 = -10
par_lo$adt1 = -20
par_lo$adt2 = -10
par_lo$adp1 = -10
par_lo$adp2 = -10

par_lo$bc0 = -20
par_lo$bct1 = -10
par_lo$bct2 = -10
par_lo$bcp1 = -20
par_lo$bcp2 = -10

par_lo$bd0 = - 10
par_lo$bdt1 = -10
par_lo$bdt2 = -10
par_lo$bdp1 = -20
par_lo$bdp2 = -10

par_lo$tc0 = - 10
par_lo$tct1 = -10
par_lo$tct2 = -10
par_lo$tcp1 = -10
par_lo$tcp2 = -10

par_lo$td0 = - 10 
par_lo$tdt1 = -10
par_lo$tdt2 = -10
par_lo$tdp1 = -10
par_lo$tdp2 = -10

par_lo$e0 = -20
par_lo$et1 = -10
par_lo$et2 = -10
par_lo$ep1 = -10
par_lo$ep2 = -10

# Upper bounds
par_hi = list()
par_hi$ac0 = 10
par_hi$act1 = 10
par_hi$act2 = 10
par_hi$acp1 = 10
par_hi$acp2 = 20

par_hi$ad0 = 10
par_hi$adt1 = 10
par_hi$adt2 = 10
par_hi$adp1 = 10
par_hi$adp2 = 20

par_hi$bc0 = 10
par_hi$bct1 = 10
par_hi$bct2 = 10
par_hi$bcp1 = 10
par_hi$bcp2 = 10

par_hi$bd0 = 10
par_hi$bdt1 = 10
par_hi$bdt2 = 10
par_hi$bdp1 = 10
par_hi$bdp2 = 10

par_hi$tc0 = 10
par_hi$tct1 = 10
par_hi$tct2 = 20
par_hi$tcp1 = 10
par_hi$tcp2 = 10

par_hi$td0 = 10
par_hi$tdt1 = 10
par_hi$tdt2 = 10
par_hi$tdp1 = 10
par_hi$tdp2 = 10

par_hi$e0 = 10
par_hi$et1 = 10
par_hi$et2 = 10
par_hi$ep1 = 20
par_hi$ep2 = 10